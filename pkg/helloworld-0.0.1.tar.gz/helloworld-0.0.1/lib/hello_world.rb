module HelloWorld
  def self.say_hello
    puts "Hello World"
  end
end
